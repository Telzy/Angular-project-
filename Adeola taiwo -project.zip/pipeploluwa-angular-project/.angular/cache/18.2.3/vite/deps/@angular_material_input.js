import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-FATJIYP3.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-Z2THCCFO.js";
import "./chunk-NCSRWVFS.js";
import "./chunk-TNVEPSH6.js";
import "./chunk-VEZGAPSL.js";
import "./chunk-74UPLWOU.js";
import "./chunk-RILH4CBY.js";
import "./chunk-HSNK2NXK.js";
import "./chunk-FETPF7OR.js";
import "./chunk-25AXBXWS.js";
import "./chunk-EAXIUE4G.js";
import "./chunk-FLFNY6JX.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
