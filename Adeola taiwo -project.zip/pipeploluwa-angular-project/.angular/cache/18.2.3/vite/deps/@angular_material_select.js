import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-V7H3ATUP.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-Z2THCCFO.js";
import "./chunk-NCSRWVFS.js";
import "./chunk-TNVEPSH6.js";
import "./chunk-VEZGAPSL.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-74UPLWOU.js";
import "./chunk-DZ232FYV.js";
import "./chunk-7JHNZ6UR.js";
import "./chunk-VTWI7B5H.js";
import "./chunk-ONHTYWS5.js";
import "./chunk-RILH4CBY.js";
import "./chunk-HSNK2NXK.js";
import "./chunk-FETPF7OR.js";
import "./chunk-25AXBXWS.js";
import "./chunk-EAXIUE4G.js";
import "./chunk-FLFNY6JX.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
