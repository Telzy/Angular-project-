import {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
} from "./chunk-S4AFALBN.js";
import "./chunk-ONHTYWS5.js";
import "./chunk-FLFNY6JX.js";
export {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
};
//# sourceMappingURL=@angular_cdk_accordion.js.map
