import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-Y5BNM5T3.js";
import "./chunk-UC43MJ7S.js";
import "./chunk-YABI4QIU.js";
import "./chunk-PRQLH3Z6.js";
import "./chunk-BMXJAABB.js";
import "./chunk-5Z3E2ZX6.js";
import "./chunk-XKMCCLCQ.js";
import "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";
export {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
