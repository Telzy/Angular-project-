import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-WBBJOABD.js";
import "./chunk-WADH6FIV.js";
import "./chunk-INXXWWB4.js";
import "./chunk-UC43MJ7S.js";
import "./chunk-YABI4QIU.js";
import "./chunk-PRQLH3Z6.js";
import "./chunk-BMXJAABB.js";
import "./chunk-5Z3E2ZX6.js";
import "./chunk-XKMCCLCQ.js";
import "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map
