import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
} from "./chunk-PYQJGNEB.js";
import "./chunk-IWYWX7YL.js";
import "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";
export {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
};
//# sourceMappingURL=@angular_cdk_accordion.js.map
