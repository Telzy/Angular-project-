import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BasePortalHost,
  BasePortalOutlet,
  CdkPortal,
  CdkPortalOutlet,
  ComponentPortal,
  DomPortal,
  DomPortalHost,
  DomPortalOutlet,
  Portal,
  PortalHostDirective,
  PortalInjector,
  PortalModule,
  TemplatePortal,
  TemplatePortalDirective
} from "./chunk-IBFTUKG6.js";
import "./chunk-XKMCCLCQ.js";
import "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";
export {
  BasePortalHost,
  BasePortalOutlet,
  CdkPortal,
  CdkPortalOutlet,
  ComponentPortal,
  DomPortal,
  DomPortalHost,
  DomPortalOutlet,
  Portal,
  PortalHostDirective,
  PortalInjector,
  PortalModule,
  TemplatePortal,
  TemplatePortalDirective
};
//# sourceMappingURL=@angular_cdk_portal.js.map
