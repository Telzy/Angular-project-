import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-4VVBAU5I.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-EZE7LWPT.js";
import "./chunk-RESJZY7B.js";
import "./chunk-C23Z5CTY.js";
import "./chunk-GRG66QQ4.js";
import "./chunk-UC43MJ7S.js";
import "./chunk-YABI4QIU.js";
import "./chunk-PRQLH3Z6.js";
import "./chunk-BMXJAABB.js";
import "./chunk-5Z3E2ZX6.js";
import "./chunk-XKMCCLCQ.js";
import "./chunk-GPPHCCFQ.js";
import "./chunk-NQ4HTGF6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
