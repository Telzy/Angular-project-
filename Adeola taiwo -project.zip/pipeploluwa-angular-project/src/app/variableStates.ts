import { ICustomerDatas } from "./pages-components/customer-pages/interfaces/customer";

export let dataSource!:ICustomerDatas;
