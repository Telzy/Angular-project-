import { Component } from '@angular/core';

@Component({
  selector: 'app-spinner-progress',
  templateUrl: './spinner-progress.component.html',
  styleUrl: './spinner-progress.component.css'
})
export class SpinnerProgressComponent {

}
